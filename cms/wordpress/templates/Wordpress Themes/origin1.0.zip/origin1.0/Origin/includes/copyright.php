<footer id="main-footer">
	<p id="copyright"><?php printf( __( 'Designed by %1$s | Powered by %2$s', 'Origin' ), '<a href="http://www.elegantthemes.com" title="Premium WordPress Themes">Elegant Themes</a>', '<a href="http://www.wordpress.org">WordPress</a>' ); ?></p>
</footer> <!-- #main-footer -->