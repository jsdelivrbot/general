<?php
/**
 * Sidebar
 *
 * @since alterna 1.0
 */
?>

<?php dynamic_sidebar('sidebar'); ?>

