<?php
/**
 * Header Style 1
 * 
 * @since alterna 1.0
 */
 ?>
<!-- logo & social -->
<div id="alterna-header" class="row-fluid header-style-1">
    <div class="logo">
        <a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>"><?php if(alterna_get_options_key('logo-txt-enable')  == "yes") echo '<h2>'.get_bloginfo( 'name' ).'</h2>'; ?></a>
    </div>
    <?php if(intval(alterna_get_options_key('header-right-area-type')) == 0) : ?>
    <div class="header-social-container">
        <ul class="inline alterna-social header-social">
            <?php 
            echo alterna_get_social_list(); 
            if(alterna_get_options_key('rss-feed') != "") echo '<li><a title="'.__('rss','alterna').'" href="'.alterna_get_options_key('rss-feed').'" class="alterna-icon-rss"></a></li>';
            ?>
        </ul>
     </div>
     <?php else : ?>
     <div class="header-custom-container">
        <?php echo do_shortcode(alterna_get_options_key('header-right-area-content')); ?>
     </div>
     <?php endif; ?>
</div>

<!-- mobile show drop select menu -->
<div id="alterna-drop-nav" class="row-fluid navbar">
    <div id="alterna-nav-menu-select" class="navbar-inverse">
        <button type="button" class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
         </button>
         <div class="nav-collapse collapse"><ul class="nav"></ul></div>
    </div>
</div>

<!-- menu & search form -->
<nav id="alterna-nav" class="row-fluid <?php echo (alterna_get_options_key('header-search-enable') == "yes") ? "show-search" :""; ?>"">
    <div class="container">
    <?php if(alterna_get_options_key('fixed-enable') == "yes") : ?>
    <div class="fixed-logo">
        <a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>"></a>
    </div>
    <?php endif; ?>
    <?php 
        $alterna_main_menu = array(
            'theme_location'  	=> 'alterna_menu',
            'container_class'	=> 'alterna-nav-menu-container',
            'menu_class'    	=> 'alterna-nav-menu',
            'fallback_cb'	  	=> 'alterna_show_setting_primary_menu'
        ); 
        wp_nav_menu($alterna_main_menu);
    ?>
    <?php if(alterna_get_options_key('header-search-enable') == "yes") : ?>
    <div class="alterna-nav-form-container">
        <div class="alterna-nav-form">
            <form role="search" class="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
               <div>
                   <input id="sf-s" name="s" type="text" placeholder="<?php _e('Search','alterna'); ?>" />
                   <input id="sf-searchsubmit" type="submit" value="" />
               </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    </div>
</nav>